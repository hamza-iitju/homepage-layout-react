import React from 'react';

const Home = React.lazy(() => import('./views/Home'));
const Colors = React.lazy(() => import('./views/Theme/Colors'));
const Layouts = React.lazy(() => import('./views/Theme/Layouts'));
const Students = React.lazy(() => import('./views/Students/Students'));
const Student = React.lazy(() => import('./views/Students/Student'));

const routes = [
  { path: '/home', name: 'Home', component: Home },
  { path: '/theme', exact: true, name: 'Theme', component: Colors },
  { path: '/theme/colors', name: 'Colors', component: Colors },
  { path: '/theme/layouts', name: 'Layouts', component: Layouts },
  { path: '/students', exact: true,  name: 'Students', component: Students },
  { path: '/students/:id', exact: true, name: 'Student Details', component: Student },
];

export default routes;
