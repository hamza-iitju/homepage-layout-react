import React from 'react';
import ReactDOM from 'react-dom';
import Layouts from './Layouts';

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<Layouts />, div);
  ReactDOM.unmountComponentAtNode(div);
});