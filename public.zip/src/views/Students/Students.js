import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Badge, Card, CardBody, CardHeader, Col, Row, Table } from 'reactstrap';

import studentsData from './StudentsData'

function StudentRow(props) {
  const student = props.student
  const studentLink = `/students/${student.id}`

  const getBadge = (status) => {
    return status === 'Active' ? 'success' :
      status === 'Inactive' ? 'secondary' :
        status === 'Pending' ? 'warning' :
          status === 'Banned' ? 'danger' :
            'primary'
  }

  return (
    <tr key={student.id.toString()}>
      <th scope="row"><Link to={studentLink}>{student.id}</Link></th>
      <td><Link to={studentLink}>{student.name}</Link></td>
      <td>{student.registered}</td>
      <td>{student.role}</td>
      <td><Link to={studentLink}><Badge color={getBadge(student.status)}>{student.status}</Badge></Link></td>
    </tr>
  )
}

class Students extends Component {

  render() {

    const studentList = studentsData.filter((student) => student.id < 10)

    return (
      <div className="animated fadeIn">
        <Row>
          <Col xl={6}>
            <Card>
              <CardHeader>
                <i className="fa fa-align-justify"></i> Students <small className="text-muted">example</small>
              </CardHeader>
              <CardBody>
                <Table responsive hover>
                  <thead>
                    <tr>
                      <th scope="col">id</th>
                      <th scope="col">name</th>
                      <th scope="col">registered</th>
                      <th scope="col">role</th>
                      <th scope="col">status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {studentList.map((student, index) =>
                      <StudentRow key={index} student={student}/>
                    )}
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    )
  }
}

export default Students;
