import React from 'react';
import {MemoryRouter} from 'react-router-dom';
import { mount } from 'enzyme'
import Students from './Students';


it('renders without crashing', () => {
  const wrapper = mount(
    <MemoryRouter>
      <Students match={{params: {id: "1"}, isExact: true, path: "/students/:id", name: "Student details"}}/>
    </MemoryRouter>
  );
  expect(wrapper.containsMatchingElement(<strong>Samppa Nori</strong>)).toEqual(true)
  wrapper.unmount()
});
