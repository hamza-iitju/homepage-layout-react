export default {
  items: [{
      name: 'Home',
      url: '/home',
      icon: 'icon-speedometer',
      badge: {
        variant: 'info',
      },
    },
    {
      divider: true,
    },
    {
      title: true,
      name: 'Main Menu',
    },
    {
      name: 'Academic',
      url: '/academic',
      icon: 'icon-star',
      children: [{
          name: 'Subject',
          url: '/subject',
          icon: 'icon-star',
        },
        {
          name: 'Progress',
          url: '/progress',
          icon: 'icon-star',
        },
        {
          name: 'Model Test',
          url: '/model-test',
          icon: 'icon-star',
        },
        {
          name: 'Routine',
          url: '/routine',
          icon: 'icon-star',
        },
      ],
    },
    {
      name: 'Questions',
      url: '/questions',
      icon: 'icon-puzzle',
    },
    {
      name: 'Accounts',
      url: '/accounts',
      icon: 'icon-cursor',
      children: [{
          name: 'Messages',
          url: '/messages',
          icon: 'icon-cursor',
        },
        {
          name: 'Tasks',
          url: '/tasks',
          icon: 'icon-cursor',
        },
        {
          name: 'Comments',
          url: '/comments',
          icon: 'icon-cursor',
        },
      ],
    },
    {
      name: 'Settings',
      url: '/settings',
      icon: 'icon-star',
      children: [{
          name: 'Profile',
          url: '/profile',
          icon: 'icon-star',
        },
        {
          name: 'Settings',
          url: '/settings',
          icon: 'icon-star',
        },
        {
          name: 'Payments',
          url: '/payments',
          icon: 'icon-star',
        },
        {
          name: 'Delete Account',
          url: '/delete-account',
          icon: 'icon-star',
        },
      ],
    },
    {
      name: 'Notifications',
      url: '/notifications',
      icon: 'icon-bell',
    },
    {
      name: 'Logout',
      url: '/logout',
      icon: 'icon-pie-chart',
    },
    {
      title: true,
      name: 'Theme',
    },
    {
      name: 'Colors',
      url: '/theme/colors',
      icon: 'icon-drop',
    },
    {
      name: 'Layouts',
      url: '/theme/layouts',
      icon: 'icon-layers',
    },
  ],
};